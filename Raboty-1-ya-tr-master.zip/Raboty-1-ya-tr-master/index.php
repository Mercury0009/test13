
<head>
<title>🚚 <? $APPLICATION->ShowTitle(); ?></title>
</head>
<!--introduction start-->
<div class="introduction">
	<div class="container">
		<div class="row">
			<div class="col-md-7 col-lg-7 col-xs-12">
				<h1 class="white-header"> <span class="white-header__back white-header__back_bold">Транспортная компания №1 <br> </span> <span class="white-header__back"> перевозка грузов <br>по России, СНГ и Европе</span> </h1>
			</div>
			<div class="col-md-5 col-xs-12 col-lg-5 form_top">
				 <?$APPLICATION->IncludeComponent(
	"custom:order.do.feedback",
	".default",
	Array(
		"AJAX_MODE" => "Y",
		"AJAX_OPTION_ADDITIONAL" => "",
		"AJAX_OPTION_HISTORY" => "N",
		"AJAX_OPTION_JUMP" => "N",
		"AJAX_OPTION_STYLE" => "N",
		"COMPONENT_TEMPLATE" => ".default",
		"EMAIL_TO" => DEFAULT_EMAIL,
		"EVENT_MESSAGE_ID" => array(0=>"15",),
		"HEADER_FORM" => "Сделать заказ",
		"OK_TEXT" => "Ваше сообщение принято",
		"REQUIRED_FIELDS" => array(0=>"NAME",1=>"EMAIL",2=>"MESSAGE",3=>"PHONE",),
		"SUBMIT_TEXT" => "Заказать перевозку",
		"USE_CAPTCHA" => "N"
	)
);?>
			</div>
			<div class="col-xs-12 form_top_mobi">
 <span class="button button_theme-orange center-header__button _js-order" data-text="Сделать заказ" data-name="Заявка через кнопку в шапке мобильном">Сделать заказ</span>
			</div>
		</div>
	</div>
	<div class="scroll scroll_js">
	</div>
</div>
 <!--introduction end-->
<div class="how-work">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">как мы работаем</h2>
 <span class="cntn-sub-header">Компания 1-я Транспортная располагает обширным автопарком грузового транспорта, <br>
				 что позволяет организовать перевозку практически любого груза</span>
				<div class="how-work__list">
					<div class="how-work__item ">
						<div class="how-work__wrap">
							<div class="how-work__picture how-work__picture_icon-mail">
							</div>
 <span class="how-work__number">1</span> <span class="how-work__text">Отправляете запрос менеджеру</span>
						</div>
 <span class="how-work__line"></span>
					</div>
					<div class="how-work__item ">
						<div class="how-work__wrap">
							<div class="how-work__picture how-work__picture_icon-calc">
							</div>
 <span class="how-work__number">2</span> <span class="how-work__text">Уточняем детали и рассчитываем цену</span>
						</div>
 <span class="how-work__line"></span>
					</div>
					<div class="how-work__item ">
						<div class="how-work__wrap">
							<div class="how-work__picture how-work__picture_icon-list">
							</div>
 <span class="how-work__number">3</span> <span class="how-work__text">Присылаем счет</span>
						</div>
 <span class="how-work__line"></span>
					</div>
					<div class="how-work__item">
						<div class="how-work__wrap">
							<div class="how-work__picture how-work__picture_icon-car">
							</div>
 <span class="how-work__number">4</span> <span class="how-work__text">Доставка вашего груза</span>
						</div>
 <span class="how-work__line"></span>
					</div>
					<div class="how-work__item ">
						<div class="how-work__wrap">
							<div class="how-work__picture how-work__picture_icon-man">
							</div>
 <span class="how-work__number">5</span> <span class="how-work__text">Работа выполнена, клиент доволен!</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="main-services">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">Перевезем любой груз</h2>
 <span class="cntn-sub-header">Качественно, быстро и недорого перевезем Ваш груз по России, СНГ и Европе</span>
			</div>
			<div class="col-xs-12">
				 <?$APPLICATION->IncludeComponent(
	"bitrix:menu", 
	"services-list", 
	array(
		"ALLOW_MULTI_SELECT" => "N",
		"CHILD_MENU_TYPE" => "left",
		"COMPONENT_TEMPLATE" => "services-list",
		"DELAY" => "N",
		"MAX_LEVEL" => "2",
		"MENU_CACHE_GET_VARS" => array(
		),
		"MENU_CACHE_TIME" => "3600",
		"MENU_CACHE_TYPE" => "A",
		"MENU_CACHE_USE_GROUPS" => "N",
		"ROOT_MENU_TYPE" => "top",
		"USE_EXT" => "N"
	),
	false
);?>
			</div>
		</div>
	</div>
</div>
 <!--Benefits-->
<div class="benefits around">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">Наши преимущества</h2>
 <span class="cntn-sub-header">Несколько веских причин выбрать нас для перевозки Ваших грузов</span>
			</div>
			<div class="col-xs-12">
				<div class="square-block">
					<div class="square-block__item square-block__item_orange">
						<div class="square-block__wrap">
 <img alt="услуги грузоперевозок" src="/local/templates/1trk/images/benefits/one.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Персональный менеджер</span> <span class="square-block__desc">готов ответить на все вопросы</span>
					</div>
					<div class="square-block__item square-block__item_blue">
						<div class="square-block__wrap">
 <img alt="оплата услуг грузоперевозок" src="/local/templates/1trk/images/benefits/two.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Удобная форма оплаты</span> <span class="square-block__desc"> безналичный расчет с НДС и без НДС, перевод на карту Сбербанка, <span class="square-block__link"><a href="/onlayn-oplata/">оплата через сайт</a></span></span>
					</div>
					<div class="square-block__item square-block__item_lightblue">
						<div class="square-block__wrap">
 <img alt="оказание услуг грузоперевозок" src="local/templates/1trk/images/benefits/three.jpg" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Полный пакет документов</span> <span class="square-block__desc">для юридических и физических лиц</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

 <!--Benefits--> <!-- advantages --> <?$APPLICATION->IncludeComponent(
	"custom:slider",
	"template1",
	Array(
		"CACHE_TIME" => "3600000",
		"CACHE_TYPE" => "A",
		"COMPONENT_TEMPLATE" => ".default",
		"HEADER" => "Нам доверяют",
		"HEIGHT" => "150",
		"IBLOCK_TYPE_ID" => IBLOCK_ID_ADVANTAGES,
		"SLIDE_COUNT" => "20",
		"SUBHEADER" => "Мы заботимся о сохранении репутации ответственной и надежной компании. <br>Нас можно рекомендовать друзьям, клиентам, партнерам",
		"WIDTH" => "250"
	)
);?> <!-- advantages --> <!-- Reliability -->
<div class="reliability around">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">Работать с нами надежно</h2>
 <span class="cntn-sub-header">Вместе с компанией 1-я Транспортная Ваши грузы в надежный руках</span>
			</div>
			<div class="col-xs-12">
				<div class="square-block">
					<div class="square-block__item square-block__item_small square-block__item_lightblue">
						<div class="square-block__wrap">
 <img alt="перевозки для торгово-промышленной палаты" src="/local/templates/1trk/images/reliability/reliability_1.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Члены ТПП</span> <span class="square-block__desc">мы являемся членами Торгово-промышленной палаты с 2008 года</span>
					</div>
					<div class="square-block__item square-block__item_small square-block__item_blue">
						<div class="square-block__wrap">
 <img alt="международные грузоперевозки" src="/local/templates/1trk/images/reliability/reliability_2.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Опыт работы</span> <span class="square-block__desc">успешно доставляем Ваши грузы с 2000 года</span>
					</div>
					<div class="square-block__item square-block__item_small square-block__item_orange">
						<div class="square-block__wrap">
 <img alt="международные грузоперевозки" src="/local/templates/1trk/images/reliability/reliability_3.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Страховка груза и рисков</span> <span class="square-block__desc">все грузы, которые мы перевозим, застрахованы</span>
					</div>
					<div class="square-block__item square-block__item_small square-block__item_lightblue">
						<div class="square-block__wrap">
 <img alt="перевозки для поволжской логистической ассоциации" src="/local/templates/1trk/images/reliability/reliability_4.png" alt="" class="square-block__image lazy">
						</div>
 <span class="square-block__name">Участник ПЛА</span> <span class="square-block__desc">являемся членами Поволжской Логистической Ассоциации с 2009 года</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
 <!--Reliability end--> <!--about-->
<div class="about">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">О компании</h2>
 <span class="cntn-sub-header">Мы рады приветствовать Вас на сайте нашей компании!</span>
			</div>
			<div class="col-xs-12">
				<h3 class="about__header">Для вас, как для себя</h3>
				<p>
					 1-я Транспортная компания с 2000 года оказывает комплекс транспортно-логистических услуг и имеет дело с деловыми людьми, которые ценят высокий сервис. Такими, как мы сами.
				</p>
				<h3 class="about__header">Станьте одним из тех, кого называют «клиент на всю жизнь»</h3>
				<div class="video-container col-xs-6">
					 <iframe class="iframe-youtube" height="316" src="https://www.youtube.com/embed/mDuL2nkAJI0?modestbranding=1"></iframe>
				</div>
				<p>
					 1-я Транспортная практикует серьезный подход к делу и дорожит деловыми связями, именно поэтому 80% компаний, воспользовавшихся транспортно-логистическими услугами, становятся нашими постоянными клиентами. Мы уверены, что наша компания поможет и Вам в продвижении бизнеса, своевременно и в полном объеме выполняя возложенные на нас задачи.
				</p>
				<p>Будем рады видеть Вас среди клиентов, доверивших решение транспортно-логистических задач 1-й Транспортной — компании, которая делает для Вас все, как для себя.</p>
				<p>
					 Мы всегда открыты к диалогу, и Вы в любой момент можете узнать о том, как мы работаем, получить ответы на вопросы и профессиональную консультативную помощь, поскольку мы делаем все, чтобы оправдать Ваше доверие.
				</p>
				<p>
					 Мы работаем так, чтобы вы были довольны высоким уровнем сервиса, соответствующего мировым стандартам в сфере транспортной логистики.
				</p>
			</div>
		</div>
	</div>
</div>
 <!--about end--> <!--reviews-->
<div class="reviews">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h2 class="cntn-header">Отзывы наших клиентов</h2>
 <span class="cntn-sub-header">Самая большая ценность для нас — это Ваши отзывы. <br>
				 Вы не раз по достоинству оценили качество услуг и высокий уровень сервиса нашей компании. </span>
			</div>
			<div class="col-xs-12">
				<div class="row">
					 <?$APPLICATION->IncludeComponent(
	"bitrix:news.list",
	"text-reviews",
	Array(
		"ACTIVE_DATE_FORMAT" => "j F Y",
		"ADD_SECTIONS_CHAIN" => "N",
		"AJAX_MODE" => "N",
		"AJAX_OPTION_ADDITIONAL" => "",
		"AJAX_OPTION_HISTORY" => "N",
		"AJAX_OPTION_JUMP" => "N",
		"AJAX_OPTION_STYLE" => "N",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "N",
		"CACHE_TIME" => "36000000",
		"CACHE_TYPE" => "A",
		"CHECK_DATES" => "Y",
		"COMPONENT_TEMPLATE" => "text-reviews",
		"DETAIL_URL" => "",
		"DISPLAY_BOTTOM_PAGER" => "N",
		"DISPLAY_DATE" => "Y",
		"DISPLAY_NAME" => "Y",
		"DISPLAY_PICTURE" => "Y",
		"DISPLAY_PREVIEW_TEXT" => "Y",
		"DISPLAY_TOP_PAGER" => "N",
		"FIELD_CODE" => array(0=>"",1=>"",),
		"FILTER_NAME" => "",
		"HIDE_LINK_WHEN_NO_DETAIL" => "N",
		"IBLOCK_ID" => IBLOCK_ID_REVIEWS_TEXT,
		"IBLOCK_TYPE" => "CONTENT",
		"INCLUDE_IBLOCK_INTO_CHAIN" => "N",
		"INCLUDE_SUBSECTIONS" => "N",
		"MESSAGE_404" => "",
		"NEWS_COUNT" => "2",
		"PAGER_BASE_LINK_ENABLE" => "N",
		"PAGER_DESC_NUMBERING" => "N",
		"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
		"PAGER_SHOW_ALL" => "N",
		"PAGER_SHOW_ALWAYS" => "N",
		"PAGER_TEMPLATE" => ".default",
		"PAGER_TITLE" => "Новости",
		"PARENT_SECTION" => "",
		"PARENT_SECTION_CODE" => "",
		"PREVIEW_TRUNCATE_LEN" => "",
		"PROPERTY_CODE" => array(0=>"SITY",1=>"CARGO",2=>"DIRECTION",3=>"",),
		"SET_BROWSER_TITLE" => "N",
		"SET_LAST_MODIFIED" => "N",
		"SET_META_DESCRIPTION" => "N",
		"SET_META_KEYWORDS" => "N",
		"SET_STATUS_404" => "N",
		"SET_TITLE" => "N",
		"SHOW_404" => "N",
		"SORT_BY1" => "ACTIVE_FROM",
		"SORT_BY2" => "SORT",
		"SORT_ORDER1" => "DESC",
		"SORT_ORDER2" => "ASC",
		"STRICT_SECTION_CHECK" => "N"
	)
);?>
				</div>
			</div>
			<div class="col-xs-12 text-center">
 <a href="/otzyvy/" class="button button_theme-blue" data-text="все отзывы">все отзывы</a>
			</div>
		</div>
	</div>
</div>
 <!--reviews-->
<div class="enter around">
	<div class="enter__car">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<h2 class="cntn-header">1-я транспортная — ваш залог успеха</h2>
 <span class="cntn-sub-header">перевозим грузы для Вас с 2000 года</span>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<h3 class="enter__header">С 1-й Транспортной можно иметь дело, поскольку мы:</h3>
					<ul>
						<li>Предлагаем оптимальные схемы работы </li>
						<li>Предоставляем качественные транспортные услуги</li>
						<li>Четко исполняем условия договора </li>
						<li>Соблюдаем сроки</li>
						<li>Можем работать в режиме «срочно»</li>
						<li>Выстраиваем гибкую финансовую политику по оплате услуги</li>
						<li>Допускаем отсрочку платежей </li>
						<li>Предоставляем скидки для корпоративных клиентов и на разовые перевозки</li>
						<li>Проводим консультирование клиентов</li>
						<li>Предоставляем достоверную информацию о нахождении груза</li>
						<li>Подходим к каждому заказу индивидуально </li>
						<li>Оперативно реагируем на пожелания и требования клиентов</li>
					</ul>
					<p>
						 Мы знаем, что выполнять взятые на себя обязательства и работать, соблюдая законы — правильно. Так мы и работаем, заботясь о сохранении репутации ответственной и надежной компании. Нас можно рекомендовать друзьям, клиентам, партнерам.
					</p>
 <br>
 <br>
 <a href="/raschet-stoimosti/" class="button button_theme-orange enter__button" data-text="рассчитать стоимость перевозки">
					рассчитать стоимость перевозки </a> <br>
 <br>
 <br>
 <br>
				</div>
			</div>
		</div>
	</div>
</div>
<br>